# DISENO
Sección encargada del diseño, a cargo de Juan Jose Figueroa Ayala (Lider), Darwin Garcia Andrade (Modelaje de datos), Jose Manuel Torres (Modelaje de datos) Y
Victor Gomez (Modelaje Diagramas)
